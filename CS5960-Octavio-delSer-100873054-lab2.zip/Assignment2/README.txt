Assignment 2 octavio del ser 100873054

Source code -> .py

Visual reports -> .html .pdf .ipynb

Recommendation for reading report:
Read the report in the .ipynb format if possible
otherwise .html (keeps the report on one page rather than breaking it up in pdf)


Reasoning: the generated output is long (agent movement is contained in a 
scrollable div with the .ipynb notebook)

Reccomentation for running:
change the print function to the original one
I changed it because it was incompatible with the latex -> 
pdf generator I used to generate the pdf file. 

Adjust the speed from 0.01.


