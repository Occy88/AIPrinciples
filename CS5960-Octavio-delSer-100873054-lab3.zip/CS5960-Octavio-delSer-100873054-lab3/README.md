Assignment 3 octavio del ser 100873054

I did not use Jupyter for this lab due to the way the code was presented.
Pictures of solutions achieved are included in pdf.

No code was modified, I made a vector class to isolate
code that was specific to calculating heuristics,
(mostly one liners.)